# 🚀 Simulador do Rover Espacial

Sistema completo com **Lexer → Parser → AST → Simulador** para a linguagem de controle do Rover.

---

## 📁 Estrutura de Arquivos

```
rover/
├── lexer.py          # Analisador Léxico (texto → tokens)
├── ast_nodes.py      # Nós da AST (estrutura interna dos comandos)
├── parser.py         # Analisador Sintático (tokens → AST)
├── compiler.py       # Fachada: orquestra Lexer + Parser
├── simulator.py      # Motor de simulação no grid 2D
├── main.py           # Ponto de entrada (CLI)
└── exemplos/
    ├── exemplo_basico.rover     # Comandos simples
    ├── exemplo_avancado.rover   # IF OBSTACLE + REPEAT
    └── exemplo_erros.rover      # Erros propositais para teste
```

---

## ⚙️ Requisitos

- **Python 3.10+** (usa `match/case` internamente via dataclasses)
- Nenhuma biblioteca externa necessária — apenas a stdlib!

---

## 🚀 Como Usar

### 1. Modo Demo (mais fácil para começar)

```bash
python main.py --demo
```

Executa um script de demonstração completo que mostra todos os recursos.

---

### 2. Modo Arquivo

```bash
python main.py --file exemplos/exemplo_basico.rover
```

Com visualização da AST compilada:

```bash
python main.py --file exemplos/exemplo_avancado.rover --ast
```

---

### 3. Modo Interativo (REPL)

```bash
python main.py
```

Digite comandos linha a linha. **Linha em branco** executa o buffer acumulado.

Comandos especiais no REPL:

| Comando | Ação |
|---------|------|
| *(linha vazia)* | Executa os comandos digitados |
| `novo`  | Reseta o rover para posição inicial |
| `mapa`  | Exibe o grid atual |
| `ast`   | Mostra a AST do buffer atual |
| `ajuda` | Exibe referência da linguagem |
| `sair`  | Encerra o REPL |

---

## 📖 Linguagem do Rover

### Comandos Básicos

| Comando         | Descrição                              |
|-----------------|----------------------------------------|
| `FORWARD <n>`   | Avança **n** posições na direção atual |
| `BACKWARD <n>`  | Recua **n** posições                   |
| `LEFT`          | Gira 90° à esquerda                    |
| `RIGHT`         | Gira 90° à direita                     |
| `DETECT`        | Detecta obstáculo à frente             |

### Controle de Fluxo (Bônus)

| Comando                        | Descrição                                   |
|--------------------------------|---------------------------------------------|
| `IF OBSTACLE THEN <cmd>`       | Executa `<cmd>` se houver obstáculo à frente |
| `REPEAT <n> ( <comandos> )`    | Repete o bloco **n** vezes                  |

### Comentários

```
# isto é um comentário e será ignorado
FORWARD 3  # comentário no fim de linha também funciona
```

### Exemplo de Script Completo

```
# Missão de exploração
FORWARD 3
RIGHT
DETECT
IF OBSTACLE THEN LEFT
REPEAT 2 (
    FORWARD 2
    DETECT
)
BACKWARD 1
```

---

## 🗺️ Ambiente de Simulação

- **Grid:** 10 × 10 (posições de 0 a 9 em X e Y)
- **Posição inicial:** (0, 0) — canto inferior esquerdo
- **Direção inicial:** Norte (↑)
- **Obstáculos padrão:** (3,3), (3,4), (6,7), (5,2), (8,5)

### Legenda do Mapa

| Símbolo | Significado |
|---------|-------------|
| `↑ ↓ ← →` | Rover (com sua direção atual) |
| `▓`     | Obstáculo   |
| `·`     | Célula livre |

---

## ❌ Tratamento de Erros

O compilador detecta e reporta:

| Tipo de Erro | Exemplo |
|---|---|
| Comando inválido | `GIRAR_ESQUERDA` |
| Parâmetro inválido | `FORWARD -5` |
| Sintaxe incorreta | `IF THEN RIGHT` (sem OBSTACLE) |
| Bloco mal fechado | `REPEAT 3 (` sem `)` |

O simulador trata:

- Tentativa de sair dos limites do grid (bloqueio sem crash)
- Colisão com obstáculo (para na célula anterior)

---

## 🏗️ Arquitetura

```
Código-fonte (.rover)
       │
       ▼
   [ LEXER ]          → Tokenização (texto → tokens)
       │
       ▼
   [ PARSER ]         → Análise sintática (tokens → AST)
       │
       ▼
   [ AST ]            → Estrutura interna dos comandos
       │
       ▼
  [ SIMULATOR ]       → Execução no grid 2D
       │
       ▼
  Log + Mapa visual
```
