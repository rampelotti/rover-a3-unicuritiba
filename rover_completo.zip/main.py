"""
main.py - Space Rover Simulator entry point
Supports:
  1. Interactive mode (REPL)
  2. File mode      (--file script.rover)
  3. Demo mode      (--demo)
"""

import argparse
import sys
import os
from compiler import Compiler, CompilerError
from simulator import Simulator, Direction, SimulationError
from map_config import MAP_COLS, MAP_ROWS, generate_obstacles

# ── Default environment configuration ────────────────────────────────────────
DEFAULT_COLS = MAP_COLS
DEFAULT_ROWS = MAP_ROWS
DEFAULT_X = 0
DEFAULT_Y = 0
DEFAULT_DIR = Direction.NORTH


# ── Quick language reference ─────────────────────────────────────────────────
LANGUAGE_HELP = """
╔══════════════════════════════════════════════════════════╗
║           SPACE ROVER LANGUAGE v1.0                      ║
╠══════════════════════════════════════════════════════════╣
║  Basic commands:                                         ║
║    FORWARD  <n>   → Move forward n steps                 ║
║    BACKWARD <n>   → Move backward n steps                ║
║    LEFT           → Turn 90° left                        ║
║    RIGHT          → Turn 90° right                       ║
║    DETECT         → Detect obstacle ahead                ║
║                                                          ║
║  Flow control (bonus):                                   ║
║    IF OBSTACLE THEN <cmd>  → If obstacle ahead           ║
║    REPEAT <n> ( <cmds> )   → Repeat n times              ║
║                                                          ║
║  Comments:  # text until end of line                     ║
╚══════════════════════════════════════════════════════════╝
"""


# ── Helper functions ───────────────────────────────────────────────────────────
def make_simulator(
    cols=DEFAULT_COLS,
    rows=DEFAULT_ROWS,
    x=DEFAULT_X,
    y=DEFAULT_Y,
    direction=DEFAULT_DIR,
    obstacles=None,
) -> Simulator:
    obs = obstacles if obstacles is not None else generate_obstacles(cols, rows, x, y)
    return Simulator(cols, rows, x, y, direction, obs)


def run_source(source: str, sim: Simulator, show_ast: bool = False):
    compiler = Compiler()
    try:
        if show_ast:
            program = compiler.compile_and_show(source)
        else:
            program = compiler.compile(source)
        sim.run(program)
        sim.print_log()
        sim.print_grid()
    except (CompilerError, SimulationError) as e:
        print(f"\n❌  {e}\n")


# ── DEMO mode ─────────────────────────────────────────────────────────────────
DEMO_SCRIPT = """\
# Space Rover demonstration script
# Starting position: (0,0) facing North

FORWARD 2
RIGHT
FORWARD 3
DETECT
IF OBSTACLE THEN LEFT
FORWARD 1
LEFT
REPEAT 2 (
    FORWARD 2
    DETECT
)
BACKWARD 1
"""


def run_demo():
    print("\n🚀  DEMO MODE — Full Rover simulation\n")
    print("Script to execute:")
    print("─" * 40)
    print(DEMO_SCRIPT)
    print("─" * 40)
    sim = make_simulator()
    run_source(DEMO_SCRIPT, sim, show_ast=True)


# ── FILE mode ─────────────────────────────────────────────────────────────────
def run_file(path: str, show_ast: bool):
    if not os.path.isfile(path):
        print(f"❌  File not found: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        source = f.read()
    print(f"\n📄  Running file: {path}\n")
    sim = make_simulator()
    run_source(source, sim, show_ast=show_ast)


# ── INTERACTIVE mode (REPL) ────────────────────────────────────────────────────
def run_interactive():
    print("\n🚀  SPACE ROVER SIMULATOR — Interactive Mode")
    print(LANGUAGE_HELP)
    print("  Type commands (one instruction per line).")
    print("  Blank line to run | 'new' to reset | 'exit' to quit\n")

    sim = make_simulator()
    compiler = Compiler()
    lines = []

    while True:
        try:
            prompt = "... " if lines else ">>> "
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print("\n👋  Goodbye.")
            break

        lower = line.strip().lower()

        if lower == "exit":
            print("👋  Goodbye.")
            break

        if lower == "new":
            sim = make_simulator()
            lines = []
            print("✅  Rover reset to starting position with a new map.\n")
            continue

        if lower == "map":
            sim.print_grid()
            continue

        if lower == "help":
            print(LANGUAGE_HELP)
            continue

        if lower == "ast":
            src = "\n".join(lines)
            if src.strip():
                try:
                    compiler.compile_and_show(src)
                except CompilerError as e:
                    print(f"❌  {e}\n")
            else:
                print("  (empty buffer)\n")
            continue

        # Blank line → run buffer
        if line.strip() == "":
            if not lines:
                continue
            source = "\n".join(lines)
            lines = []
            run_source(source, sim)
            continue

        lines.append(line)


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Space Rover Simulator"
    )
    parser.add_argument("--file", "-f", help="Path to a .rover script")
    parser.add_argument("--demo", "-d", action="store_true", help="Run demonstration script")
    parser.add_argument("--ast", "-a", action="store_true", help="Show compiled AST")
    args = parser.parse_args()

    if args.demo:
        run_demo()
    elif args.file:
        run_file(args.file, show_ast=args.ast)
    else:
        run_interactive()


if __name__ == "__main__":
    main()
