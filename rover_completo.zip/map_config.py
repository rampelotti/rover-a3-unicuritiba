import random
from typing import Set, Tuple

MAP_COLS = 15
MAP_ROWS = 15

WALL_DENSITY = 0.10


def generate_obstacles(
    cols: int = MAP_COLS,
    rows: int = MAP_ROWS,
    start_x: int = 0,
    start_y: int = 0,
    density: float = WALL_DENSITY,
    seed: int | None = None,
) -> Set[Tuple[int, int]]:
    if seed is not None:
        random.seed(seed)

    protected = {(start_x, start_y)}
    for dx, dy in ((0, 1), (1, 0), (0, -1), (-1, 0)):
        nx, ny = start_x + dx, start_y + dy
        if 0 <= nx < cols and 0 <= ny < rows:
            protected.add((nx, ny))

    candidates = [
        (x, y)
        for x in range(cols)
        for y in range(rows)
        if (x, y) not in protected
    ]

    wall_count = max(1, int(len(candidates) * density))
    return set(random.sample(candidates, min(wall_count, len(candidates))))
