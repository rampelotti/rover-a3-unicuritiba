"""
autopilot.py - Space Rover Autopilot Mode
The rover automatically avoids obstacles when trying to move.
"""

import random
import time
from simulator import Simulator, Direction, SimulationError


class Autopilot:
    """
    Runs FORWARD commands with automatic obstacle avoidance.
    When an obstacle is detected, turns randomly left or right and retries.
    """

    MAX_DETOURS = 4

    def __init__(self, sim: Simulator, delay: float = 0.0):
        self.sim   = sim
        self.delay = delay

    # ------------------------------------------------------------------ public
    def move(self, steps: int):
        """Move `steps` cells with automatic detours."""
        remaining = steps

        while remaining > 0:
            if self.delay:
                time.sleep(self.delay)

            if self._obstacle_ahead():
                self._detour()
            else:
                self._step_forward()
                remaining -= 1

    def turn_left(self):
        self.sim.state.direction = self.sim.state.direction.turn_left()
        self.sim._log("LEFT (autopilot)", f"Turned to {self.sim.state.direction.value}")

    def turn_right(self):
        self.sim.state.direction = self.sim.state.direction.turn_right()
        self.sim._log("RIGHT (autopilot)", f"Turned to {self.sim.state.direction.value}")

    def detect(self):
        found = self._obstacle_ahead()
        msg = "⚠ Obstacle detected ahead!" if found else "✓ Clear path."
        self.sim._log("DETECT (autopilot)", msg)
        return found

    # ------------------------------------------------------------------ private
    def _obstacle_ahead(self) -> bool:
        dx, dy = self.sim.state.direction.delta()
        nx = self.sim.state.x + dx
        ny = self.sim.state.y + dy
        if not (0 <= nx < self.sim.cols and 0 <= ny < self.sim.rows):
            return True
        return (nx, ny) in self.sim.obstacles

    def _step_forward(self):
        dx, dy = self.sim.state.direction.delta()
        self.sim.state.x += dx
        self.sim.state.y += dy
        self.sim._log(
            "FORWARD 1 (autopilot)",
            f"Moved to ({self.sim.state.x},{self.sim.state.y})"
        )

    def _detour(self):
        side = random.choice(["left", "right"])
        print(f"\n  🚨 AUTOPILOT: Obstacle detected ahead!")
        print(f"  🔄 Turning {side} automatically...\n")

        if side == "left":
            new_dir = self.sim.state.direction.turn_left()
        else:
            new_dir = self.sim.state.direction.turn_right()

        self.sim._log(
            f"AUTO-DETOUR → {side.upper()}",
            f"Obstacle blocked path! Turning to {new_dir.value}"
        )
        self.sim.state.direction = new_dir

        attempts = 0
        while self._obstacle_ahead() and attempts < self.MAX_DETOURS:
            attempts += 1
            side2 = random.choice(["left", "right"])
            print(f"  ⚠  Still blocked! Trying to turn {side2}...\n")
            if side2 == "left":
                new_dir = self.sim.state.direction.turn_left()
            else:
                new_dir = self.sim.state.direction.turn_right()
            self.sim.state.direction = new_dir
            self.sim._log(
                f"AUTO-DETOUR (attempt {attempts}) → {side2.upper()}",
                f"Turning to {new_dir.value}"
            )

        if self._obstacle_ahead():
            print("  ❌  Rover trapped! Unable to continue.\n")
            self.sim._log("AUTO-DETOUR FAILED", "Rover surrounded by obstacles.")
            raise SimulationError("Rover trapped — autopilot could not find a way out.")
