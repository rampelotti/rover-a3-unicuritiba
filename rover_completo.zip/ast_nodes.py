"""
ast_nodes.py - Nós da Árvore Sintática Abstrata (AST)
Cada classe representa uma instrução da linguagem do Rover.
"""

from dataclasses import dataclass, field
from typing import List


# ── Nó base ──────────────────────────────────────────────────────────────────
@dataclass
class ASTNode:
    line: int = field(default=0, repr=False)


# ── Comandos simples ──────────────────────────────────────────────────────────
@dataclass
class ForwardCmd(ASTNode):
    steps: int = 0

    def __repr__(self):
        return f"FORWARD({self.steps})"


@dataclass
class BackwardCmd(ASTNode):
    steps: int = 0

    def __repr__(self):
        return f"BACKWARD({self.steps})"


@dataclass
class LeftCmd(ASTNode):
    def __repr__(self):
        return "LEFT"


@dataclass
class RightCmd(ASTNode):
    def __repr__(self):
        return "RIGHT"


@dataclass
class DetectCmd(ASTNode):
    def __repr__(self):
        return "DETECT"


# ── Estruturas de controle (bônus) ────────────────────────────────────────────
@dataclass
class IfObstacleThenCmd(ASTNode):
    """IF OBSTACLE THEN <cmd>"""
    consequence: ASTNode = field(default=None)

    def __repr__(self):
        return f"IF OBSTACLE THEN {self.consequence}"


@dataclass
class RepeatCmd(ASTNode):
    """REPEAT n ( <cmds> )"""
    times: int = 0
    body: List[ASTNode] = field(default_factory=list)

    def __repr__(self):
        body_str = ", ".join(str(c) for c in self.body)
        return f"REPEAT({self.times}, [{body_str}])"


# ── Programa completo ─────────────────────────────────────────────────────────
@dataclass
class Program:
    commands: List[ASTNode]

    def __repr__(self):
        return "\n".join(f"  {c}" for c in self.commands)
