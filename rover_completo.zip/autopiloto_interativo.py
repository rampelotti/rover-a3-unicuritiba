"""
autopiloto_interativo.py
Interactive autopilot mode — the rover avoids obstacles on its own.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from simulator import Simulator, Direction, SimulationError
from autopilot import Autopilot
from map_config import MAP_COLS, MAP_ROWS, generate_obstacles

HELP = """
╔══════════════════════════════════════════════════════╗
║         ROVER — AUTOPILOT MODE                       ║
╠══════════════════════════════════════════════════════╣
║  FORWARD <n>   → Move n steps (auto-dodges!)         ║
║  BACKWARD <n>  → Move backward n steps               ║
║  LEFT          → Turn left                           ║
║  RIGHT         → Turn right                          ║
║  DETECT        → Check for obstacle ahead            ║
║                                                      ║
║  map           → Show current grid                   ║
║  new           → Reset rover and regenerate map      ║
║  help          → Show this screen                    ║
║  exit          → Quit                                ║
╚══════════════════════════════════════════════════════╝
"""


def make_sim() -> Simulator:
    obstacles = generate_obstacles(MAP_COLS, MAP_ROWS, 0, 0)
    return Simulator(MAP_COLS, MAP_ROWS, 0, 0, Direction.NORTH, obstacles)


def process_command(line: str, sim: Simulator, ap: Autopilot) -> bool:
    """Process a command. Returns False to quit."""
    parts = line.strip().upper().split()
    if not parts:
        return True

    cmd = parts[0]

    if cmd == "EXIT":
        return False

    if cmd == "NEW":
        return "NEW"

    if cmd == "MAP":
        sim.print_grid()
        return True

    if cmd == "HELP":
        print(HELP)
        return True

    if cmd == "FORWARD":
        if len(parts) < 2 or not parts[1].isdigit():
            print("  ❌  Usage: FORWARD <number>  e.g. FORWARD 3\n")
            return True
        n = int(parts[1])
        if n <= 0:
            print("  ❌  Number must be greater than zero.\n")
            return True
        try:
            ap.move(n)
        except SimulationError as e:
            print(f"  ❌  {e}\n")
        sim.print_log()
        sim.print_grid()
        sim.log.clear()
        sim._step = 0
        return True

    if cmd == "BACKWARD":
        if len(parts) < 2 or not parts[1].isdigit():
            print("  ❌  Usage: BACKWARD <number>  e.g. BACKWARD 2\n")
            return True
        n = int(parts[1])
        sim.state.direction = sim.state.direction.turn_left().turn_left()
        try:
            ap.move(n)
        except SimulationError as e:
            print(f"  ❌  {e}\n")
        sim.state.direction = sim.state.direction.turn_left().turn_left()
        sim.print_log()
        sim.print_grid()
        sim.log.clear()
        sim._step = 0
        return True

    if cmd == "LEFT":
        ap.turn_left()
        sim.print_log()
        sim.print_grid()
        sim.log.clear()
        sim._step = 0
        return True

    if cmd == "RIGHT":
        ap.turn_right()
        sim.print_log()
        sim.print_grid()
        sim.log.clear()
        sim._step = 0
        return True

    if cmd == "DETECT":
        ap.detect()
        sim.print_log()
        sim.log.clear()
        sim._step = 0
        return True

    print(f"  ❌  Unknown command: '{line.strip()}'")
    print("  Type 'help' to see available commands.\n")
    return True


def main():
    print("\n🚀  SPACE ROVER — AUTOPILOT MODE")
    print("  The rover dodges obstacles automatically!\n")
    print(HELP)

    sim = make_sim()
    ap = Autopilot(sim)
    sim.print_grid()

    while True:
        try:
            line = input(">>> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n👋  Goodbye.")
            break

        result = process_command(line, sim, ap)

        if result == "NEW":
            sim = make_sim()
            ap = Autopilot(sim)
            print("✅  Rover reset to starting position (0,0) North with a new map.\n")
            sim.print_grid()
            continue

        if result is False:
            print("👋  Goodbye.")
            break


if __name__ == "__main__":
    main()
