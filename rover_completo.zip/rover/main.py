"""
main.py - Ponto de entrada do Simulador do Rover Espacial
Suporta:
  1. Modo interativo (REPL)
  2. Modo arquivo   (--file script.rover)
  3. Modo demo      (--demo)
"""

import argparse
import sys
import os
from compiler import Compiler, CompilerError
from simulator import Simulator, Direction, SimulationError

# ── Configuração padrão do ambiente ──────────────────────────────────────────
DEFAULT_COLS  = 10
DEFAULT_ROWS  = 10
DEFAULT_X     = 0
DEFAULT_Y     = 0
DEFAULT_DIR   = Direction.NORTH
DEFAULT_OBSTACLES = {(3, 3), (3, 4), (6, 7), (5, 2), (8, 5)}


# ── Referência rápida da linguagem ───────────────────────────────────────────
LANGUAGE_HELP = """
╔══════════════════════════════════════════════════════════╗
║           LINGUAGEM DO ROVER ESPACIAL v1.0               ║
╠══════════════════════════════════════════════════════════╣
║  Comandos básicos:                                       ║
║    FORWARD  <n>   → Avança n posições                    ║
║    BACKWARD <n>   → Recua  n posições                    ║
║    LEFT           → Gira 90° à esquerda                  ║
║    RIGHT          → Gira 90° à direita                   ║
║    DETECT         → Detecta obstáculo à frente           ║
║                                                          ║
║  Controle de fluxo (bônus):                              ║
║    IF OBSTACLE THEN <cmd>  → Se houver obstáculo         ║
║    REPEAT <n> ( <cmds> )   → Repete n vezes              ║
║                                                          ║
║  Comentários:  # texto até o fim da linha                ║
╚══════════════════════════════════════════════════════════╝
"""


# ── Funções auxiliares ────────────────────────────────────────────────────────
def make_simulator(cols=DEFAULT_COLS, rows=DEFAULT_ROWS,
                   x=DEFAULT_X, y=DEFAULT_Y,
                   direction=DEFAULT_DIR,
                   obstacles=None) -> Simulator:
    obs = obstacles if obstacles is not None else DEFAULT_OBSTACLES
    return Simulator(cols, rows, x, y, direction, obs)


def run_source(source: str, sim: Simulator, show_ast: bool = False):
    compiler = Compiler()
    try:
        if show_ast:
            program = compiler.compile_and_show(source)
        else:
            program = compiler.compile(source)
        sim.run(program)
        sim.print_log()
        sim.print_grid()
    except (CompilerError, SimulationError) as e:
        print(f"\n❌  {e}\n")


# ── Modo DEMO ─────────────────────────────────────────────────────────────────
DEMO_SCRIPT = """\
# Script de demonstração do Rover Espacial
# Posição inicial: (0,0) direção Norte

FORWARD 2
RIGHT
FORWARD 3
DETECT
IF OBSTACLE THEN LEFT
FORWARD 1
LEFT
REPEAT 2 (
    FORWARD 2
    DETECT
)
BACKWARD 1
"""


def run_demo():
    print("\n🚀  MODO DEMO — Simulação completa do Rover\n")
    print("Script a ser executado:")
    print("─" * 40)
    print(DEMO_SCRIPT)
    print("─" * 40)
    sim = make_simulator()
    run_source(DEMO_SCRIPT, sim, show_ast=True)


# ── Modo ARQUIVO ──────────────────────────────────────────────────────────────
def run_file(path: str, show_ast: bool):
    if not os.path.isfile(path):
        print(f"❌  Arquivo não encontrado: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        source = f.read()
    print(f"\n📄  Executando arquivo: {path}\n")
    sim = make_simulator()
    run_source(source, sim, show_ast=show_ast)


# ── Modo INTERATIVO (REPL) ────────────────────────────────────────────────────
def run_interactive():
    print("\n🚀  SIMULADOR DO ROVER ESPACIAL — Modo Interativo")
    print(LANGUAGE_HELP)
    print("  Digite os comandos (uma instrução por linha).")
    print("  Linha em branco para executar | 'novo' para resetar | 'sair' para encerrar\n")

    sim = make_simulator()
    compiler = Compiler()
    lines = []

    while True:
        try:
            prompt = "... " if lines else ">>> "
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print("\n👋  Encerrando.")
            break

        lower = line.strip().lower()

        if lower == "sair":
            print("👋  Encerrando.")
            break

        if lower == "novo":
            sim = make_simulator()
            lines = []
            print("✅  Rover resetado para posição inicial.\n")
            continue

        if lower == "mapa":
            sim.print_grid()
            continue

        if lower == "ajuda":
            print(LANGUAGE_HELP)
            continue

        if lower == "ast":
            src = "\n".join(lines)
            if src.strip():
                try:
                    compiler.compile_and_show(src)
                except CompilerError as e:
                    print(f"❌  {e}\n")
            else:
                print("  (buffer vazio)\n")
            continue

        # Linha em branco → executa o buffer
        if line.strip() == "":
            if not lines:
                continue
            source = "\n".join(lines)
            lines  = []
            run_source(source, sim)
            continue

        lines.append(line)


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Simulador do Rover Espacial"
    )
    parser.add_argument("--file",  "-f", help="Caminho para script .rover")
    parser.add_argument("--demo",  "-d", action="store_true", help="Executa script de demonstração")
    parser.add_argument("--ast",   "-a", action="store_true", help="Exibe a AST compilada")
    args = parser.parse_args()

    if args.demo:
        run_demo()
    elif args.file:
        run_file(args.file, show_ast=args.ast)
    else:
        run_interactive()


if __name__ == "__main__":
    main()
