"""
compiler.py - Compilador da Linguagem do Rover
Orquestra: Lexer → Parser → AST
"""

from lexer import Lexer, LexerError
from parser import Parser, ParserError
from ast_nodes import Program


class CompilerError(Exception):
    pass


class Compiler:
    """
    Fachada (facade) para o pipeline de compilação.
    Recebe código-fonte e retorna um Program (AST) pronto para execução.
    """

    def compile(self, source: str) -> Program:
        # 1) Análise léxica
        try:
            lexer  = Lexer(source)
            tokens = lexer.tokenize()
        except LexerError as e:
            raise CompilerError(str(e)) from e

        # 2) Análise sintática
        try:
            parser  = Parser(tokens)
            program = parser.parse()
        except ParserError as e:
            raise CompilerError(str(e)) from e

        return program

    def compile_and_show(self, source: str) -> Program:
        """Compila e exibe a AST resultante."""
        program = self.compile(source)
        print("══════════════════ AST COMPILADA ══════════════════")
        print(program)
        print("═══════════════════════════════════════════════════\n")
        return program
