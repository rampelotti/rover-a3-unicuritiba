"""
autopiloto_interativo.py
Modo interativo do autopiloto — o rover desvia sozinho dos obstáculos.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from simulator import Simulator, Direction, SimulationError
from autopilot import Autopilot

# ── Configuração do ambiente ──────────────────────────────────────────────────
COLS      = 10
ROWS      = 10
OBSTACLES = {(3, 3), (3, 4), (6, 7), (5, 2), (8, 5)}

AJUDA = """
╔══════════════════════════════════════════════════════╗
║         ROVER — MODO AUTOPILOTO                     ║
╠══════════════════════════════════════════════════════╣
║  FORWARD <n>   → Anda n casas (desvia sozinho!)     ║
║  BACKWARD <n>  → Recua n casas                      ║
║  LEFT          → Gira à esquerda                    ║
║  RIGHT         → Gira à direita                     ║
║  DETECT        → Verifica obstáculo à frente        ║
║                                                     ║
║  mapa          → Mostra o grid atual                ║
║  novo          → Reseta o rover                     ║
║  ajuda         → Mostra esta tela                   ║
║  sair          → Encerra                            ║
╚══════════════════════════════════════════════════════╝
"""


def make_sim() -> Simulator:
    return Simulator(COLS, ROWS, 0, 0, Direction.NORTH, OBSTACLES)


def processar(linha: str, sim: Simulator, ap: Autopilot) -> bool:
    """Processa um comando. Retorna False se deve sair."""
    partes = linha.strip().upper().split()
    if not partes:
        return True

    cmd = partes[0]

    if cmd == "SAIR":
        return False

    if cmd == "NOVO":
        # Reinicia — sinaliza para o chamador
        return "NOVO"

    if cmd == "MAPA":
        sim.print_grid()
        return True

    if cmd == "AJUDA":
        print(AJUDA)
        return True

    if cmd == "FORWARD":
        if len(partes) < 2 or not partes[1].isdigit():
            print("  ❌  Use: FORWARD <número>  ex: FORWARD 3\n")
            return True
        n = int(partes[1])
        if n <= 0:
            print("  ❌  O número deve ser maior que zero.\n")
            return True
        try:
            ap.mover(n)
        except SimulationError as e:
            print(f"  ❌  {e}\n")
        sim.print_log()
        sim.print_grid()
        sim.log.clear()
        sim._step = 0
        return True

    if cmd == "BACKWARD":
        if len(partes) < 2 or not partes[1].isdigit():
            print("  ❌  Use: BACKWARD <número>  ex: BACKWARD 2\n")
            return True
        n = int(partes[1])
        # Recuar = girar 180° + mover + girar 180°
        sim.state.direction = sim.state.direction.turn_left().turn_left()
        try:
            ap.mover(n)
        except SimulationError as e:
            print(f"  ❌  {e}\n")
        sim.state.direction = sim.state.direction.turn_left().turn_left()
        sim.print_log()
        sim.print_grid()
        sim.log.clear()
        sim._step = 0
        return True

    if cmd == "LEFT":
        ap.girar_esquerda()
        sim.print_log()
        sim.print_grid()
        sim.log.clear()
        sim._step = 0
        return True

    if cmd == "RIGHT":
        ap.girar_direita()
        sim.print_log()
        sim.print_grid()
        sim.log.clear()
        sim._step = 0
        return True

    if cmd == "DETECT":
        tem = ap.detectar()
        sim.print_log()
        sim.log.clear()
        sim._step = 0
        return True

    print(f"  ❌  Comando desconhecido: '{linha.strip()}'")
    print("  Digite 'ajuda' para ver os comandos disponíveis.\n")
    return True


def main():
    print("\n🚀  ROVER ESPACIAL — MODO AUTOPILOTO")
    print("  O rover desvia sozinho dos obstáculos!\n")
    print(AJUDA)

    sim = make_sim()
    ap  = Autopilot(sim)
    sim.print_grid()

    while True:
        try:
            linha = input(">>> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n👋  Encerrando.")
            break

        resultado = processar(linha, sim, ap)

        if resultado == "NOVO":
            sim = make_sim()
            ap  = Autopilot(sim)
            print("✅  Rover resetado para posição inicial (0,0) Norte.\n")
            sim.print_grid()
            continue

        if resultado is False:
            print("👋  Encerrando.")
            break


if __name__ == "__main__":
    main()
