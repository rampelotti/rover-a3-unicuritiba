"""
autopilot.py - Modo Autopiloto do Rover Espacial
O rover desvia automaticamente de obstáculos ao tentar se mover.
"""

import random
import time
from simulator import Simulator, Direction, SimulationError


class Autopilot:
    """
    Executa comandos FORWARD com desvio automático de obstáculos.
    Ao detectar um obstáculo, gira para um lado aleatório e tenta continuar.
    """

    MAX_DESVIOS = 4  # tentativas máximas de desvio antes de desistir

    def __init__(self, sim: Simulator, delay: float = 0.0):
        self.sim   = sim
        self.delay = delay  # pausa entre passos (modo animado)

    # ------------------------------------------------------------------ public
    def mover(self, steps: int):
        """Anda `steps` casas com desvio automático."""
        passos_restantes = steps

        while passos_restantes > 0:
            if self.delay:
                time.sleep(self.delay)

            if self._obstaculo_a_frente():
                self._desviar()
            else:
                self._andar_um()
                passos_restantes -= 1

    def girar_esquerda(self):
        self.sim.state.direction = self.sim.state.direction.turn_left()
        self.sim._log("LEFT (autopiloto)", f"Girou para {self.sim.state.direction.value}")

    def girar_direita(self):
        self.sim.state.direction = self.sim.state.direction.turn_right()
        self.sim._log("RIGHT (autopiloto)", f"Girou para {self.sim.state.direction.value}")

    def detectar(self):
        tem = self._obstaculo_a_frente()
        msg = "⚠ Obstáculo detectado à frente!" if tem else "✓ Caminho livre."
        self.sim._log("DETECT (autopiloto)", msg)
        return tem

    # ------------------------------------------------------------------ private
    def _obstaculo_a_frente(self) -> bool:
        dx, dy = self.sim.state.direction.delta()
        nx = self.sim.state.x + dx
        ny = self.sim.state.y + dy
        if not (0 <= nx < self.sim.cols and 0 <= ny < self.sim.rows):
            return True
        return (nx, ny) in self.sim.obstacles

    def _andar_um(self):
        dx, dy = self.sim.state.direction.delta()
        self.sim.state.x += dx
        self.sim.state.y += dy
        self.sim._log(
            "FORWARD 1 (autopiloto)",
            f"Moveu para ({self.sim.state.x},{self.sim.state.y})"
        )

    def _desviar(self):
        lado = random.choice(["esquerda", "direita"])
        print(f"\n  🚨 AUTOPILOTO: Obstáculo detectado em frente!")
        print(f"  🔄 Girando para a {lado} automaticamente...\n")

        if lado == "esquerda":
            nova_dir = self.sim.state.direction.turn_left()
        else:
            nova_dir = self.sim.state.direction.turn_right()

        self.sim._log(
            f"AUTO-DESVIO → {lado.upper()}",
            f"Obstáculo bloqueou! Girando para {nova_dir.value}"
        )
        self.sim.state.direction = nova_dir

        # Se após girar ainda estiver bloqueado, tenta o outro lado
        tentativas = 0
        while self._obstaculo_a_frente() and tentativas < self.MAX_DESVIOS:
            tentativas += 1
            lado2 = random.choice(["esquerda", "direita"])
            print(f"  ⚠  Ainda bloqueado! Tentando virar para {lado2}...\n")
            if lado2 == "esquerda":
                nova_dir = self.sim.state.direction.turn_left()
            else:
                nova_dir = self.sim.state.direction.turn_right()
            self.sim.state.direction = nova_dir
            self.sim._log(
                f"AUTO-DESVIO (tentativa {tentativas}) → {lado2.upper()}",
                f"Girando para {nova_dir.value}"
            )

        if self._obstaculo_a_frente():
            print("  ❌  Rover cercado! Não foi possível continuar.\n")
            self.sim._log("AUTO-DESVIO FALHOU", "Rover cercado por obstáculos.")
            raise SimulationError("Rover cercado — autopiloto não conseguiu desviar.")
