"""
simulator.py - Motor de Simulação do Rover Espacial
Executa a AST em um grid 2D com obstáculos.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Set, Tuple, Optional
from ast_nodes import (
    ASTNode, Program,
    ForwardCmd, BackwardCmd, LeftCmd, RightCmd, DetectCmd,
    IfObstacleThenCmd, RepeatCmd,
)


# ── Direções ──────────────────────────────────────────────────────────────────
class Direction(Enum):
    NORTH = "Norte (↑)"
    EAST  = "Leste (→)"
    SOUTH = "Sul  (↓)"
    WEST  = "Oeste (←)"

    def turn_left(self) -> "Direction":
        order = [Direction.NORTH, Direction.WEST, Direction.SOUTH, Direction.EAST]
        return order[(order.index(self) + 1) % 4]

    def turn_right(self) -> "Direction":
        order = [Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST]
        return order[(order.index(self) + 1) % 4]

    def delta(self) -> Tuple[int, int]:
        """Retorna (dx, dy) — y cresce para cima (Norte)."""
        return {
            Direction.NORTH: ( 0,  1),
            Direction.EAST:  ( 1,  0),
            Direction.SOUTH: ( 0, -1),
            Direction.WEST:  (-1,  0),
        }[self]

    def arrow(self) -> str:
        return {"NORTH": "↑", "EAST": "→", "SOUTH": "↓", "WEST": "←"}[self.name]


# ── Estado do Rover ───────────────────────────────────────────────────────────
@dataclass
class RoverState:
    x:         int
    y:         int
    direction: Direction

    def __str__(self) -> str:
        return f"({self.x}, {self.y}) dir={self.direction.arrow()}"


# ── Tipos de evento de log ────────────────────────────────────────────────────
@dataclass
class LogEntry:
    step:    int
    command: str
    state:   RoverState
    message: str = ""

    def __str__(self) -> str:
        state_str = f"pos=({self.state.x},{self.state.y}) dir={self.state.direction.arrow()}"
        msg = f"  ⚠  {self.message}" if self.message else ""
        return f"[{self.step:03d}] {self.command:<30} → {state_str}{msg}"


# ── Simulador ────────────────────────────────────────────────────────────────
class SimulationError(Exception):
    pass


class Simulator:
    """
    Executa os comandos da AST em um grid (cols × rows).

    Coordenadas: (0,0) = canto inferior-esquerdo.
    """

    def __init__(
        self,
        cols:       int,
        rows:       int,
        start_x:    int,
        start_y:    int,
        start_dir:  Direction,
        obstacles:  Optional[Set[Tuple[int, int]]] = None,
    ):
        if not (0 <= start_x < cols and 0 <= start_y < rows):
            raise SimulationError("Posição inicial fora do grid.")
        self.cols      = cols
        self.rows      = rows
        self.obstacles: Set[Tuple[int, int]] = obstacles or set()
        self.state     = RoverState(start_x, start_y, start_dir)
        self.log:       List[LogEntry] = []
        self._step      = 0

    # ------------------------------------------------------------------ public
    def run(self, program: Program):
        """Executa o programa completo."""
        self.log.clear()
        self._step = 0
        for cmd in program.commands:
            self._execute(cmd)

    def print_log(self):
        print("\n═══════════════════ LOG DE EXECUÇÃO ═══════════════════")
        if not self.log:
            print("  (nenhum comando executado)")
        for entry in self.log:
            print(entry)
        print("═══════════════════════════════════════════════════════\n")

    def print_grid(self):
        """Imprime o grid com o rover e os obstáculos."""
        print("══════════════════════ MAPA FINAL ══════════════════════")
        # Linha de índice X
        header = "     " + "".join(f"{c:<3}" for c in range(self.cols))
        print(header)
        print("     " + "───" * self.cols)
        # Linhas de cima para baixo (y decrescente)
        for y in range(self.rows - 1, -1, -1):
            row = f"{y:>3}  "
            for x in range(self.cols):
                if (x, y) == (self.state.x, self.state.y):
                    row += f" {self.state.direction.arrow()} "
                elif (x, y) in self.obstacles:
                    row += " ▓ "
                else:
                    row += " · "
            print(row)
        print("     " + "───" * self.cols)
        print(f"\n  Rover: {self.state}")
        print(f"  Legenda: {self.state.direction.arrow()} = Rover  ▓ = Obstáculo  · = Livre")
        print("════════════════════════════════════════════════════════\n")

    # ------------------------------------------------------------------ private
    def _log(self, command: str, message: str = ""):
        self._step += 1
        self.log.append(
            LogEntry(self._step, command, RoverState(self.state.x, self.state.y, self.state.direction), message)
        )

    def _execute(self, node: ASTNode):
        if isinstance(node, ForwardCmd):
            self._move(node.steps, forward=True)
        elif isinstance(node, BackwardCmd):
            self._move(node.steps, forward=False)
        elif isinstance(node, LeftCmd):
            self.state.direction = self.state.direction.turn_left()
            self._log("LEFT", f"Girou para {self.state.direction.value}")
        elif isinstance(node, RightCmd):
            self.state.direction = self.state.direction.turn_right()
            self._log("RIGHT", f"Girou para {self.state.direction.value}")
        elif isinstance(node, DetectCmd):
            has_obs = self._obstacle_ahead()
            msg = "Obstáculo detectado à frente!" if has_obs else "Caminho livre à frente."
            self._log("DETECT", msg)
        elif isinstance(node, IfObstacleThenCmd):
            has_obs = self._obstacle_ahead()
            if has_obs:
                self._log("IF OBSTACLE THEN ...", "Obstáculo detectado → executando consequência")
                self._execute(node.consequence)
            else:
                self._log("IF OBSTACLE THEN ...", "Sem obstáculo → ignorando consequência")
        elif isinstance(node, RepeatCmd):
            self._log(f"REPEAT {node.times} (...)", f"Iniciando {node.times} repetição(ões)")
            for i in range(node.times):
                for sub in node.body:
                    self._execute(sub)
        else:
            raise SimulationError(f"Nó desconhecido: {type(node)}")

    def _move(self, steps: int, forward: bool):
        dx, dy = self.state.direction.delta()
        if not forward:
            dx, dy = -dx, -dy
        direction_label = "FORWARD" if forward else "BACKWARD"

        for _ in range(steps):
            nx = self.state.x + dx
            ny = self.state.y + dy

            # Fora dos limites
            if not (0 <= nx < self.cols and 0 <= ny < self.rows):
                self._log(
                    f"{direction_label} (bloqueado — limite do grid)",
                    f"Não foi possível mover para ({nx},{ny}): fora do grid."
                )
                return  # para de mover

            # Obstáculo
            if (nx, ny) in self.obstacles:
                self._log(
                    f"{direction_label} (bloqueado — obstáculo)",
                    f"Obstáculo em ({nx},{ny}). Rover parou."
                )
                return  # para de mover

            # Movimento OK
            self.state.x = nx
            self.state.y = ny
            self._log(f"{direction_label} 1", f"Moveu para ({self.state.x},{self.state.y})")

    def _obstacle_ahead(self) -> bool:
        dx, dy = self.state.direction.delta()
        nx = self.state.x + dx
        ny = self.state.y + dy
        if not (0 <= nx < self.cols and 0 <= ny < self.rows):
            return True   # borda do grid = "obstáculo"
        return (nx, ny) in self.obstacles
