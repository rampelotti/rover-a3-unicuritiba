"""
parser.py - Analisador Sintático da Linguagem do Rover
Converte lista de tokens → AST (Árvore Sintática Abstrata).
"""

from typing import List, Optional
from lexer import Token, TokenType
from ast_nodes import (
    ASTNode, Program,
    ForwardCmd, BackwardCmd, LeftCmd, RightCmd, DetectCmd,
    IfObstacleThenCmd, RepeatCmd,
)


class ParserError(Exception):
    def __init__(self, message: str, line: int, column: int):
        super().__init__(f"Erro Sintático (linha {line}, col {column}): {message}")
        self.line   = line
        self.column = column


class Parser:
    """Consome tokens e produz um Program (AST)."""

    def __init__(self, tokens: List[Token]):
        # Remove comentários e newlines — não afetam a gramática
        self.tokens = [t for t in tokens if t.type not in (TokenType.COMMENT, TokenType.NEWLINE)]
        self.pos    = 0

    # ------------------------------------------------------------------ helpers
    def _peek(self) -> Token:
        return self.tokens[self.pos]

    def _advance(self) -> Token:
        tok = self.tokens[self.pos]
        self.pos += 1
        return tok

    def _expect(self, ttype: TokenType) -> Token:
        tok = self._peek()
        if tok.type != ttype:
            raise ParserError(
                f"Esperado '{ttype.name}', encontrado '{tok.value or tok.type.name}'",
                tok.line, tok.column
            )
        return self._advance()

    def _at_end(self) -> bool:
        return self._peek().type == TokenType.EOF

    # ------------------------------------------------------------------ public
    def parse(self) -> Program:
        commands: List[ASTNode] = []
        while not self._at_end():
            commands.append(self._parse_statement())
        return Program(commands=commands)

    # ------------------------------------------------------------------ private
    def _parse_statement(self) -> ASTNode:
        tok = self._peek()

        if tok.type == TokenType.FORWARD:
            return self._parse_forward()
        if tok.type == TokenType.BACKWARD:
            return self._parse_backward()
        if tok.type == TokenType.LEFT:
            return self._parse_left()
        if tok.type == TokenType.RIGHT:
            return self._parse_right()
        if tok.type == TokenType.DETECT:
            return self._parse_detect()
        if tok.type == TokenType.IF:
            return self._parse_if_obstacle()
        if tok.type == TokenType.REPEAT:
            return self._parse_repeat()

        raise ParserError(
            f"Instrução inesperada: '{tok.value}'",
            tok.line, tok.column
        )

    # ── comandos simples ──────────────────────────────────────────────────────
    def _parse_forward(self) -> ForwardCmd:
        tok = self._advance()          # consome FORWARD
        steps = self._parse_positive_int()
        return ForwardCmd(steps=steps, line=tok.line)

    def _parse_backward(self) -> BackwardCmd:
        tok = self._advance()          # consome BACKWARD
        steps = self._parse_positive_int()
        return BackwardCmd(steps=steps, line=tok.line)

    def _parse_left(self) -> LeftCmd:
        tok = self._advance()
        return LeftCmd(line=tok.line)

    def _parse_right(self) -> RightCmd:
        tok = self._advance()
        return RightCmd(line=tok.line)

    def _parse_detect(self) -> DetectCmd:
        tok = self._advance()
        return DetectCmd(line=tok.line)

    # ── estruturas de controle ────────────────────────────────────────────────
    def _parse_if_obstacle(self) -> IfObstacleThenCmd:
        tok = self._advance()                      # consome IF
        self._expect(TokenType.OBSTACLE)           # OBSTACLE
        self._expect(TokenType.THEN)               # THEN
        consequence = self._parse_simple_cmd()     # apenas um comando simples após THEN
        return IfObstacleThenCmd(consequence=consequence, line=tok.line)

    def _parse_simple_cmd(self) -> ASTNode:
        """Aceita apenas comandos simples (sem IF/REPEAT aninhado)."""
        tok = self._peek()
        if tok.type in (TokenType.FORWARD, TokenType.BACKWARD,
                        TokenType.LEFT, TokenType.RIGHT, TokenType.DETECT):
            return self._parse_statement()
        raise ParserError(
            f"Esperado comando simples após THEN, encontrado '{tok.value}'",
            tok.line, tok.column
        )

    def _parse_repeat(self) -> RepeatCmd:
        tok  = self._advance()                     # consome REPEAT
        times = self._parse_positive_int()
        self._expect(TokenType.LPAREN)             # (
        body: List[ASTNode] = []
        while self._peek().type != TokenType.RPAREN:
            if self._at_end():
                raise ParserError("REPEAT sem ')' de fechamento", tok.line, tok.column)
            body.append(self._parse_statement())
        self._expect(TokenType.RPAREN)             # )
        if not body:
            raise ParserError("REPEAT com corpo vazio", tok.line, tok.column)
        return RepeatCmd(times=times, body=body, line=tok.line)

    # ── utilitários ───────────────────────────────────────────────────────────
    def _parse_positive_int(self) -> int:
        tok = self._peek()
        if tok.type != TokenType.NUMBER:
            raise ParserError(
                f"Esperado número inteiro positivo, encontrado '{tok.value or tok.type.name}'",
                tok.line, tok.column
            )
        self._advance()
        value = int(tok.value)
        if value <= 0:
            raise ParserError(
                f"O número deve ser maior que zero, encontrado '{value}'",
                tok.line, tok.column
            )
        return value
