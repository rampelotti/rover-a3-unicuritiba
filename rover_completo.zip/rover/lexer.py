"""
lexer.py - Analisador Léxico da Linguagem do Rover
Converte texto bruto em tokens estruturados.
"""

import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import List


class TokenType(Enum):
    # Comandos de movimento
    FORWARD  = auto()
    BACKWARD = auto()
    LEFT     = auto()
    RIGHT    = auto()
    DETECT   = auto()

    # Estruturas de controle (bônus)
    IF       = auto()
    OBSTACLE = auto()
    THEN     = auto()
    REPEAT   = auto()

    # Literais e pontuação
    NUMBER   = auto()
    LPAREN   = auto()   # (
    RPAREN   = auto()   # )

    # Metadados
    NEWLINE  = auto()
    COMMENT  = auto()
    EOF      = auto()


KEYWORDS: dict[str, TokenType] = {
    "FORWARD":   TokenType.FORWARD,
    "BACKWARD":  TokenType.BACKWARD,
    "LEFT":      TokenType.LEFT,
    "RIGHT":     TokenType.RIGHT,
    "DETECT":    TokenType.DETECT,
    "IF":        TokenType.IF,
    "OBSTACLE":  TokenType.OBSTACLE,
    "THEN":      TokenType.THEN,
    "REPEAT":    TokenType.REPEAT,
}


@dataclass
class Token:
    type:    TokenType
    value:   str
    line:    int
    column:  int

    def __repr__(self) -> str:
        return f"Token({self.type.name}, {self.value!r}, linha={self.line}, col={self.column})"


class LexerError(Exception):
    def __init__(self, message: str, line: int, column: int):
        super().__init__(f"Erro Léxico (linha {line}, col {column}): {message}")
        self.line   = line
        self.column = column


class Lexer:
    """Tokenizador: texto → lista de Token."""

    def __init__(self, source: str):
        self.source  = source
        self.pos     = 0
        self.line    = 1
        self.column  = 1
        self.tokens: List[Token] = []

    # ------------------------------------------------------------------ helpers
    def _peek(self) -> str:
        return self.source[self.pos] if self.pos < len(self.source) else ""

    def _advance(self) -> str:
        ch = self.source[self.pos]
        self.pos    += 1
        self.column += 1
        return ch

    def _make_token(self, ttype: TokenType, value: str, line: int, col: int) -> Token:
        return Token(ttype, value, line, col)

    # ------------------------------------------------------------------ public
    def tokenize(self) -> List[Token]:
        while self.pos < len(self.source):
            self._scan_token()

        self.tokens.append(Token(TokenType.EOF, "", self.line, self.column))
        return self.tokens

    # ------------------------------------------------------------------ private
    def _scan_token(self):
        ch = self._peek()

        # Espaços (ignora, exceto newline)
        if ch in (" ", "\t", "\r"):
            self._advance()
            return

        # Nova linha → registra para mensagens de erro mais claras
        if ch == "\n":
            line, col = self.line, self.column
            self._advance()
            self.line  += 1
            self.column = 1
            self.tokens.append(Token(TokenType.NEWLINE, "\\n", line, col))
            return

        # Comentário: # até fim da linha
        if ch == "#":
            line, col = self.line, self.column
            comment = ""
            while self.pos < len(self.source) and self._peek() != "\n":
                comment += self._advance()
            self.tokens.append(Token(TokenType.COMMENT, comment, line, col))
            return

        # Parênteses (para REPEAT)
        if ch == "(":
            line, col = self.line, self.column
            self._advance()
            self.tokens.append(Token(TokenType.LPAREN, "(", line, col))
            return
        if ch == ")":
            line, col = self.line, self.column
            self._advance()
            self.tokens.append(Token(TokenType.RPAREN, ")", line, col))
            return

        # Número inteiro positivo
        if ch.isdigit():
            line, col = self.line, self.column
            num = ""
            while self.pos < len(self.source) and self._peek().isdigit():
                num += self._advance()
            self.tokens.append(Token(TokenType.NUMBER, num, line, col))
            return

        # Palavra-chave / identificador
        if ch.isalpha() or ch == "_":
            line, col = self.line, self.column
            word = ""
            while self.pos < len(self.source) and (self._peek().isalnum() or self._peek() == "_"):
                word += self._advance()
            upper = word.upper()
            ttype = KEYWORDS.get(upper)
            if ttype is None:
                raise LexerError(f"Comando desconhecido: '{word}'", line, col)
            self.tokens.append(Token(ttype, upper, line, col))
            return

        # Caractere inválido
        raise LexerError(f"Caractere inválido: '{ch}'", self.line, self.column)
